package com.rli.scripts.changeEventConvertors;

import com.rli.connectors.changeevent.ChangeEvent;
import com.rli.connectors.changeevent.EventType;
import com.rli.synsvcs.common.ConnString2;
import com.rli.synsvcs.etl.changeEvents.ChangeEventConvertor;
import com.rli.web.http.json.JSONException;
import com.rli.web.http.json.JSONObject;

import java.util.Iterator;

/**
 * This class is included as a sample to show how the
 * <code>ChangeEventConvertor</code> interface can be implemented to convert
 * custom change message to <code>ChangeEvent</code> or vice-versa. To run methods in
 * this class, enter the name of this class as value for "Message Format"
 * property.
 * 
 * 
 * See oracle documentation for GoldenGateJSON format.
 * https://docs.oracle.com/goldengate/bd1221/gg-bd/GADBD/GUID-F0FA2781-0802-4530-B1F0-5E102B982EC0.htm#GADBD501
 */
public class GoldenGateJSONConvertor implements ChangeEventConvertor {

	// GoldenGate default metadata keys
	private static final String GG_TABLE_KEY = "table";
	private static final String GG_OP_TYPE_KEY = "op_type";
	private static final String GG_OP_TS_KEY = "op_ts";
	private static final String GG_CURRENT_TS_KEY = "current_ts";
	private static final String GG_POSITION_KEY = "pos";

	// keys whose value contains GoldenGate table change info
	private static final String GG_AFTER_KEY = "after";
	private static final String GG_BEFORE_KEY = "before";

	@Override
	public ChangeEvent convertToRLIChangeEvent (String goldenGateMsg) throws Exception {
		ChangeEvent changeEvent = null;
		JSONObject goldenGateJSON = null;

		try {
			goldenGateJSON = new JSONObject(goldenGateMsg);
		} catch (JSONException e) {
			throw new Exception("Parsing of input JSON message failed with exception: " + e.getMessage());
		}


		String op_type;

		try {
			op_type = goldenGateJSON.getString(GG_OP_TYPE_KEY);

		} catch (JSONException e) {
			throw new Exception(
					"Invalid GoldenGate JSON message. The key \"op_type\" is either not present or the value is empty");
		}

		if (op_type.equalsIgnoreCase("I")) {
			changeEvent = new ChangeEvent(EventType.INSERT);
			addJSONKeysToRLIMessage(goldenGateJSON.getJSONObject(GG_AFTER_KEY), changeEvent);
			applyGoldenGateMetaDataAttributes(goldenGateJSON, changeEvent);
		}
		else if (op_type.equalsIgnoreCase("U")) {
			changeEvent = new ChangeEvent(EventType.UPDATE);
			performUpdateConversion(goldenGateJSON, changeEvent);
			applyGoldenGateMetaDataAttributes(goldenGateJSON, changeEvent);
		}
		else if (op_type.equalsIgnoreCase("D")) {
			changeEvent = new ChangeEvent(EventType.DELETE);
			addJSONKeysToRLIMessage(goldenGateJSON.getJSONObject(GG_BEFORE_KEY), changeEvent);
			applyGoldenGateMetaDataAttributes(goldenGateJSON, changeEvent);
		}
		else if (op_type.equalsIgnoreCase("T")) {
			return null;
		}
		else throw new Exception("Invalid op_type");

		return changeEvent;
	}
	/**
	 * The implementation in this method does not convert to GoldenGate JSON format
	 * and its only purpose is to demonstrate how the <code>ChangeMessageList</code>
	 * and <code>ChangeMessage</code> API can be used to get all the change
	 * information
	 */

	@Override
	public String convertFromRLIChangeEvent(ChangeEvent changeEvent) throws Exception {
		String message = null;

		EventType originalType = EventType.valueOf(changeEvent.getValuesAsString(ConnString2.ORIGINAL_TYPE).get(0));

		System.out.println("Type of message: " + originalType);
		System.out.println("All the keys and their values:" + System.lineSeparator() + changeEvent);

		return "working";
	}

	private void performUpdateConversion(JSONObject goldenGateJSON, ChangeEvent changeEvent)
			throws JSONException {

		JSONObject beforeJson = goldenGateJSON.getJSONObject(GG_BEFORE_KEY);
		JSONObject afterJson = goldenGateJSON.getJSONObject(GG_AFTER_KEY);

		Iterator beforeJsonIterator = beforeJson.keys();
		while (beforeJsonIterator.hasNext()) {
			String currentKey = (String) beforeJsonIterator.next();
			String beforeValue = beforeJson.getString(currentKey);

			if (afterJson.has(currentKey) && !(afterJson.getString(currentKey)).equals(beforeValue)) {

				if (beforeJson.isNull(currentKey))
					changeEvent.addAttribute(currentKey, afterJson.getString(currentKey));
				else if (afterJson.isNull(currentKey))
					changeEvent.addAttribute(currentKey);
				else
					changeEvent.addAttribute(currentKey, afterJson.getString(currentKey));

			} else if (!beforeJson.isNull(currentKey)) {
				changeEvent.addAttribute(currentKey, beforeJson.getString(currentKey));
			}
		}
	}
	/*
	 * Helper functions which takes JSON input as argument and add key value pair to
	 * RLIMessage
	 *
	 * @JSONObject
	 *
	 * @ChangeEvent
	 */

	private void addJSONKeysToRLIMessage(JSONObject json, ChangeEvent changeEvent)
			throws JSONException {
		Iterator it = json.keys();

		while (it.hasNext()) {
			String key = (String) it.next();
			// skip keys that have null values
			if (!json.isNull(key))
				changeEvent.addAttribute(key, json.getString(key));
		}
	}

	/*
	 * Helper function takes goldenGate metadata attributes from the input json
	 * and puts into
	 *
	 * @JSONObject
	 *
	 * @ChangeEvent
	 */
	private void applyGoldenGateMetaDataAttributes(JSONObject goldenGateJson, ChangeEvent changeEvent)
			throws Exception {

		try {
			changeEvent.addAttribute(GG_TABLE_KEY, goldenGateJson.getString(GG_TABLE_KEY));
			changeEvent.addAttribute(GG_OP_TS_KEY, goldenGateJson.getString(GG_OP_TS_KEY));
			changeEvent.addAttribute(GG_CURRENT_TS_KEY, goldenGateJson.getString(GG_CURRENT_TS_KEY));
			changeEvent.addAttribute(GG_POSITION_KEY, goldenGateJson.getString(GG_POSITION_KEY));
		} catch (JSONException e) {
			throw new Exception("Missing required metadata attributes from the GoldenGate JSON message");
		}
	}
}
