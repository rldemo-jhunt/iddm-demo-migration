package com.rli.scripts.intercept;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.rli.util.djava.ScriptHelper;

public class CustomComputed {
	 public static boolean isValidDate(String dateString, String formatString) {
		 LocalDate date = parseDate(dateString, formatString);
		 return (date != null);
		 }

		 public static LocalDate parseDate(String dateString, String formatString) {
		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formatString);
		 LocalDate date = null;
		 try {
		 date = LocalDate.parse(dateString, formatter);
		 } catch (DateTimeParseException e) {
		 //
		 }
		 return date;
		 }

		 public static boolean isInPast(String dateString, String formatString) {
		 boolean result = false;
		 LocalDate date = parseDate(dateString, formatString);
		 LocalDate currentDate = LocalDate.now();
		 if(date != null && date.isBefore(currentDate))
		            result = true;
		        return result;
		 }

		 public static boolean isInFuture(String dateString, String formatString) {
		 boolean result = false;
		 LocalDate date = parseDate(dateString, formatString);
		 LocalDate currentDate = LocalDate.now();
		 if(date != null && date.isAfter(currentDate))
		            result = true;
		        
		        return result;
		 }

		 public static boolean isToday(String dateString, String formatString) {
		 boolean result = false;
		 LocalDate date = parseDate(dateString, formatString);
		 LocalDate currentDate = LocalDate.now();
		 if(date != null && date.isEqual(currentDate))
		            result = true;
		        
		        return result;
		 }
		 
		 public static String dateToTimestamp(String dateString, String formatString) {
			 String result = "";

			 DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(formatString);
			 LocalDateTime datetime = null;
			 try {
			 datetime = LocalDateTime.parse(dateString, dateTimeFormatter);
			 } catch (Exception e) {
			 //e.printStackTrace();
			 }

			 if(datetime == null) {
			 LocalDate date = parseDate(dateString, ScriptHelper.left(formatString, " "));
			 if(date != null)
			 datetime = date.atStartOfDay();
			 else
			 return "";
			 }

			 DateTimeFormatter resultFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmSSs");
			 result = datetime.format(resultFormatter);
			 return result;
			 }
		 
		 public static String computeJobStatus(String jobstartDate, String jobendDate) {

			 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
			 LocalDate startDate = null;
			 LocalDate endDate = null;

			 try {
			 if(jobstartDate != null && !jobstartDate.isEmpty())
			 startDate = LocalDate.parse(jobstartDate, formatter);

			 if(jobendDate != null && !jobendDate.isEmpty())
			 endDate = LocalDate.parse(jobendDate, formatter);
			 } catch(DateTimeParseException e) {
			 return "Invalid format for Start / End Date";
			 }

			 LocalDate currentDate = LocalDate.now();

			 //Pre-Hire
			 //IF (jobstartdate > today) AND ((jobtermdate > today) OR (jobtermdate = null)) THEN jobstatus = Pre-Hire
			 if((startDate !=null && startDate.isAfter(currentDate)) && (endDate == null || endDate.isAfter(currentDate)))
			 return "Pre-Hire";

			 //Hired
			 //IF ((jobstartdate <= today) OR (jobstartdate = null)) AND ((jobtermdate is > today) OR (jobtermdate = empty)) THEN jobstatus = Hired
			 if((startDate == null || (startDate.isBefore(currentDate) || startDate.isEqual(currentDate))) && (endDate == null || endDate.isAfter(currentDate)))
			 return "Hired";

			 //Terminated
			 //IF (jobtermdate is <= today) THEN jobstatus = Terminated
			 if(endDate != null && (endDate.isBefore(currentDate) || endDate.equals(currentDate)))
			 return "Terminated";

			 //If none of the conditions match
			 return "ComputeFailed";
			 }
		 
		 public static void main(String[] args) {
			 String format = "MM/dd/yyyy HH:mm:ss";

			 String date = "09/16/2020 11:45:20";
			 System.out.println(date + " - IsValid - " + (isValidDate(date, format) ? "Valid" : "Invalid"));
			 System.out.println(date + " - IsInPast - " + (isInPast(date, format) ? "Y" : "N"));
			 System.out.println(date + " - IsInFuture - " + (isInFuture(date, format) ? "Y" : "N"));
			 System.out.println(date + " - IsInToday - " + (isToday(date, format) ? "Y" : "N"));
			 System.out.println(date + " - -> TimeStamp -> " + dateToTimestamp(date, format));

			 date = "Jason";
			 System.out.println(date + " - IsValid - " + (isValidDate(date, format) ? "Valid" : "Invalid"));
			 System.out.println(date + " - IsInPast - " + (isInPast(date, format) ? "Y" : "N"));
			 System.out.println(date + " - IsInFuture - " + (isInFuture(date, format) ? "Y" : "N"));
			 System.out.println(date + " - IsInToday - " + (isToday(date, format) ? "Y" : "N"));
			 System.out.println(date + " - -> TimeStamp -> " + dateToTimestamp(date, format));

			 date = "09/12/2020";
			 System.out.println(date + " - IsValid - " + (isValidDate(date, format) ? "Valid" : "Invalid"));
			 System.out.println(date + " - IsInPast - " + (isInPast(date, format) ? "Y" : "N"));
			 System.out.println(date + " - IsInFuture - " + (isInFuture(date, format) ? "Y" : "N"));
			 System.out.println(date + " - IsInToday - " + (isToday(date, format) ? "Y" : "N"));
			 System.out.println(date + " - -> TimeStamp -> " + dateToTimestamp(date, format));

			 date = "09/14/2020";
			 System.out.println(date + " - IsValid - " + (isValidDate(date, format) ? "Valid" : "Invalid"));
			 System.out.println(date + " - IsInPast - " + (isInPast(date, format) ? "Y" : "N"));
			 System.out.println(date + " - IsInFuture - " + (isInFuture(date, format) ? "Y" : "N"));
			 System.out.println(date + " - IsInToday - " + (isToday(date, format) ? "Y" : "N"));
			 System.out.println(date + " - -> TimeStamp -> " + dateToTimestamp(date, format));
			 }

}
