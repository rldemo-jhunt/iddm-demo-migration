package com.rli.scripts.fidsync.dc_nydomain_o_sources_sync_object_user_ou_salesforce_o_sources;

import java.util.List;
import java.util.ArrayList;

/**
* This class provides implementations of the user-defined functions used in the 
* rule-based transformation. 
*/

public class UserDefinedFunctions {

    private UserDefinedFunctions() {
        // Static utility class: no instances.
    }

}