package com.rli.scripts.fidsync.dc_nydomain_o_sources_sync_object_user_ou_entraid_o_sources;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import com.rli.connectors.changeevent.ApprovalConfiguration;
import com.rli.connectors.changeevent.ChangeEvent;
import com.rli.connectors.changeevent.ChangeEventUtils;
import com.rli.connectors.changeevent.ChangeMode;
import com.rli.connectors.changeevent.ComplexValueUtils;
import com.rli.connectors.changeevent.EventType;
import com.rli.cragents.refresh.SyncPipelineTransformation;
import com.rli.synsvcs.rule.ComparisonType;
import com.rli.synsvcs.rule.Operator;
import com.rli.util.djava.ScriptHelper;
import com.rli.util.identityData.IdentityPatchOperation;
import com.rli.util.identityData.PatchOpType;
import org.apache.logging.log4j.Level;

import static com.rli.scripts.fidsync.dc_nydomain_o_sources_sync_object_user_ou_entraid_o_sources.UserDefinedFunctions.*;

public class Transfo_dc_nydomain_o_sources extends SyncPipelineTransformation {

    @Override
    public List<ChangeEvent> transformToList(ChangeEvent src) {
       List<ChangeEvent> destChangeEventList = new ArrayList<>();
       processRules(src, destChangeEventList);
       return destChangeEventList;
    }

   // Warning: do NOT insert code in this method as it will be overwritten when saving your pipeline rules.
   private void processRules(ChangeEvent src, List<ChangeEvent> destChangeEventList) {	// Rules Definition: NY Domain to Entra ID User
	if (ChangeEventUtils.applyCondition(src, "objectClass", "user", Operator.EQUALS, ComparisonType.IGNORECASE)) {
Map<String, Map<PatchOpType, IdentityPatchOperation>> changesMap = src.getPatchOperationsByAttributeMap();
// Local variables
List<String> AzureUPN = new ArrayList<>();

List<String> TargetDN = new ArrayList<>();
AzureUPN.clear();
AzureUPN.addAll(ChangeEventUtils.replaceAll(src.getNullSafeValuesAsString("mail"), "Globex.com", "rlidemo.onmicrosoft.com"));

TargetDN.clear();
TargetDN.addAll(ChangeEventUtils.buildExpression("user=", AzureUPN, ",object=user,ou=entraid,o=sources"));

boolean isTestMode = false;
if(isTestMode) {ChangeEvent localVarEvent = new ChangeEvent();
destChangeEventList.add(localVarEvent);
localVarEvent.addAttribute("localvar_AzureUPN", AzureUPN);
localVarEvent.addAttribute("localvar_TargetDN", TargetDN);
}

// Rule: insert rule for NY Domain to Entra ID User

log(Level.DEBUG, ChangeEventUtils.getIdentifier(src) + ", Rule (insert rule for NY Domain to Entra ID User), Condition (if 'Source Event' equals \"New entry\") = <" +(src.getEventType() == EventType.INSERT)+ ">");


if (((src.getEventType() == EventType.INSERT)))
{

log(Level.DEBUG, ChangeEventUtils.getIdentifier(src)+", Rule (insert rule for NY Domain to Entra ID User), conditions evaluated to true, executing actions...");

List<String> valuesFormail = new ArrayList<String>();
valuesFormail.addAll(src.getValuesAsString("mail"));

if (valuesFormail== null || valuesFormail.isEmpty()) { log(Level.ERROR, "Error: no values found for identity linkage, the actions for Rule (insert rule for NY Domain to Entra ID User) will not be executed."); }
for(String identityValue: valuesFormail) {
ChangeEvent dest = new ChangeEvent();
destChangeEventList.add(dest);

// Identity Linkage
dest.addAttribute("mail", identityValue);

// Attribute mappings from 'NY Domain to Entra ID User-insert-mappings'
List<String> valuesForjobTitle = new ArrayList<>();
valuesForjobTitle.addAll(src.getNullSafeValuesAsString("title"));
ChangeEventUtils.addAttribute(dest, "jobTitle", valuesForjobTitle);

// Complex Attribute mappings


// Target DN and change type setup
dest.setEventType(EventType.INSERT);
dest.setChangeMode(ChangeMode.ADAPTIVE);
dest.setEventId(TargetDN.get(0));

// Set objectclass if we need to insert a new entry
if (EventType.INSERT == dest.getEventType() || (EventType.UPDATE == dest.getEventType() && dest.getChangeMode() == ChangeMode.ADAPTIVE)) {
dest.addAttribute("objectClass", Arrays.asList("top","azureaduser") );}}
}

// Rule: update rule for NY Domain to Entra ID User

log(Level.DEBUG, ChangeEventUtils.getIdentifier(src) + ", Rule (update rule for NY Domain to Entra ID User), Condition (if 'Source Event' equals \"Updated entry\") = <" +(src.getEventType() == EventType.UPDATE)+ ">");


if (((src.getEventType() == EventType.UPDATE)))
{

log(Level.DEBUG, ChangeEventUtils.getIdentifier(src)+", Rule (update rule for NY Domain to Entra ID User), conditions evaluated to true, executing actions...");

List<String> valuesFormail = new ArrayList<String>();
valuesFormail.addAll(src.getValuesAsString("mail"));

if (valuesFormail== null || valuesFormail.isEmpty()) { log(Level.ERROR, "Error: no values found for identity linkage, the actions for Rule (update rule for NY Domain to Entra ID User) will not be executed."); }
for(String identityValue: valuesFormail) {
ChangeEvent dest = new ChangeEvent();
destChangeEventList.add(dest);

// Attribute mappings from 'NY Domain to Entra ID User-update-mappings'
List<String> valuesForjobTitle = new ArrayList<>();
valuesForjobTitle.addAll(src.getNullSafeValuesAsString("title"));
ChangeEventUtils.addAttribute(dest, "jobTitle", valuesForjobTitle);

// Complex Attribute mappings


// Target DN and change type setup
dest.setEventType(EventType.UPDATE);
dest.setChangeMode(ChangeMode.ADAPTIVE);
dest.setEventId(TargetDN.get(0));

// Set objectclass if we need to insert a new entry
if (EventType.INSERT == dest.getEventType() || (EventType.UPDATE == dest.getEventType() && dest.getChangeMode() == ChangeMode.ADAPTIVE)) {
dest.addAttribute("objectClass", Arrays.asList("top","azureaduser") );}}
}

// Rule: delete rule for NY Domain to Entra ID User

log(Level.DEBUG, ChangeEventUtils.getIdentifier(src) + ", Rule (delete rule for NY Domain to Entra ID User), Condition (if 'Source Event' equals \"Deleted entry\") = <" +(src.getEventType() == EventType.DELETE)+ ">");


if (((src.getEventType() == EventType.DELETE)))
{

log(Level.DEBUG, ChangeEventUtils.getIdentifier(src)+", Rule (delete rule for NY Domain to Entra ID User), conditions evaluated to true, executing actions...");

List<String> valuesFormail = new ArrayList<String>();
valuesFormail.addAll(src.getValuesAsString("mail"));

if (valuesFormail== null || valuesFormail.isEmpty()) { log(Level.ERROR, "Error: no values found for identity linkage, the actions for Rule (delete rule for NY Domain to Entra ID User) will not be executed."); }
for(String identityValue: valuesFormail) {
ChangeEvent dest = new ChangeEvent();
destChangeEventList.add(dest);

// Target DN and change type setup
dest.setEventType(EventType.DELETE);
dest.setChangeMode(ChangeMode.ADAPTIVE);
dest.setEventId(TargetDN.get(0));

// Set objectclass if we need to insert a new entry
if (EventType.INSERT == dest.getEventType() || (EventType.UPDATE == dest.getEventType() && dest.getChangeMode() == ChangeMode.ADAPTIVE)) {
dest.addAttribute("objectClass", Arrays.asList("top","azureaduser") );}}
}
	}}

}
