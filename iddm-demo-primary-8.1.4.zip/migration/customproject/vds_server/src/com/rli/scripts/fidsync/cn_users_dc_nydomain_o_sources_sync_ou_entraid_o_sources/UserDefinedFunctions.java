package com.rli.scripts.fidsync.cn_users_dc_nydomain_o_sources_sync_ou_entraid_o_sources;

import java.util.List;
import java.util.ArrayList;

/**
* This class provides implementations of the user-defined functions used in the 
* rule-based transformation. 
*/

public class UserDefinedFunctions {

    private UserDefinedFunctions() {
        // Static utility class: no instances.
    }

}